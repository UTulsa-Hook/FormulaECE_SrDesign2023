/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Control_initialize.c
 *
 * Code generation for function 'Control_initialize'
 *
 */

/* Include files */
#include "Control_initialize.h"
#include "Control_data.h"
#include "controlCircle.h"
#include "controlLine.h"

/* Function Definitions */
void Control_initialize(void)
{
  controlCircle_init();
  controlLine_init();
  isInitialized_Control = true;
}

/* End of code generation (Control_initialize.c) */
