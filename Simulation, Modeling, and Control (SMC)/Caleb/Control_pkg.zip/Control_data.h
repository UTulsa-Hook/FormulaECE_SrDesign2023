/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Control_data.h
 *
 * Code generation for function 'Control_data'
 *
 */

#ifndef CONTROL_DATA_H
#define CONTROL_DATA_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern double oldD;
extern double integralFactor;
extern double b_oldD;
extern boolean_T isInitialized_Control;

#endif
/* End of code generation (Control_data.h) */
