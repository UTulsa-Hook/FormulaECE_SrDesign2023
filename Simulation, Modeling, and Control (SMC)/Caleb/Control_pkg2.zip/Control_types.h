/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Control_types.h
 *
 * Code generation for function 'Control'
 *
 */

#ifndef CONTROL_TYPES_H
#define CONTROL_TYPES_H

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (Control_types.h) */
