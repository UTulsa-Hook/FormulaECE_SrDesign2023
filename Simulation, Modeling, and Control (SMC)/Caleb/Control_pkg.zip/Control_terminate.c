/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Control_terminate.c
 *
 * Code generation for function 'Control_terminate'
 *
 */

/* Include files */
#include "Control_terminate.h"
#include "Control_data.h"

/* Function Definitions */
void Control_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_Control = false;
}

/* End of code generation (Control_terminate.c) */
