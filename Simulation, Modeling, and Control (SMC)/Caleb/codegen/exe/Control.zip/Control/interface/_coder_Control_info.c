/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_Control_info.c
 *
 * Code generation for function 'Control'
 *
 */

/* Include files */
#include "_coder_Control_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[6] = {
      "789ced554f6fd3301c75a1a049885171e0dc0b1248134cdd84264e08a7a5403baaba402b"
      "823ad7713b6ffe53d2762a487c06aec027e2c8911312773e04cb12b7"
      "8945d4a2a846abf6bbfcf2fc923cff9ea317907b5acf01003641581b37c37e3dc285a85f"
      "02c932f95cd42f1b58d715904f3ca7f94f51274a8ee9741c0289059d",
      "3de929c12496e3d6fb21053e1d297e42bd33a6cf386d3141511cec07485462d40c045470"
      "0d0f2939461301fcc3d17c873c0e667e7c4b9937bfa41f24c58f82c1"
      "bf29bf850f5dc895a45de4749b74a8dc8af2c584e3322c7791efd0111bc8d27669c7452c"
      "581e3325b78a75e551cee460ab88a55784a72efa8a17efa03abceb42",
      "cc69cf8dd6ee89c45cc38c736d1ad89c4bf324f0ba8a79bfc1b1a4f3f5838cfa5753f543"
      "c653931e8fe97dcfa87794aa97e457778e4927a3e35ce8e78d25e733"
      "fbfcfe8db3fef9d78f9c4dbd93fbe4a74d3d5dff4b6f9af2be65bfcf5b297a0583af3c46"
      "cff193c6abdd1a9fa2e670da29d544c999efa3b14067d13e400ab6f5",
      "fe8bbcfefb5ce67fd79c4bf3245487cc27417c9edbbc66a97a497e85791d7752c7b5b57c"
      "f96239af6fbfc83fb2a9a76bddf37aefc1e403acbe24d471c46b78bc"
      "87db88f4ab1779bdee797d6dc15c9a8f52a6c6244de81f64d4ffd7bcce7a8e8354bd24bf"
      "f2bc0e9c3c3d4b5bb9f2d5724eb7fd8fbf6deae95af79ceeecbcc3b0",
      "dd69d58eb6777b3e7fb65fa5cd013cff39fd07ffa55608",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 4640U, &nameCaptureInfo);
  return nameCaptureInfo;
}

mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *epFieldName[6] = {
      "Name",           "NumberOfInputs", "NumberOfOutputs",
      "ConstantInputs", "FullPath",       "TimeStamp"};
  const char_T *propFieldName[5] = {"Version", "ResolvedFunctions",
                                    "EntryPoints", "CoverageInfo",
                                    "IsPolymorphic"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 6, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, (const char_T *)"Name",
                emlrtMxCreateString((const char_T *)"Control"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"ConstantInputs", xInputs);
  emlrtSetField(
      xEntryPoints, 0, (const char_T *)"FullPath",
      emlrtMxCreateString(
          (const char_T
               *)"C:\\Clone_SD_Repo\\FormulaECE_SrDesign2023\\Simulation, "
                 "Modeling, and Control (SMC)\\Caleb\\Control.m"));
  emlrtSetField(xEntryPoints, 0, (const char_T *)"TimeStamp",
                emlrtMxCreateDoubleScalar(738810.61972222221));
  xResult =
      emlrtCreateStructMatrix(1, 1, 5, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, (const char_T *)"Version",
                emlrtMxCreateString((const char_T *)"9.11.0.1769968 (R2021b)"));
  emlrtSetField(xResult, 0, (const char_T *)"ResolvedFunctions",
                (mxArray *)emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, (const char_T *)"EntryPoints", xEntryPoints);
  return xResult;
}

/* End of code generation (_coder_Control_info.c) */
