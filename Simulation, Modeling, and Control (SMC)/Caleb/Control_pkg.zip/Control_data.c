/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Control_data.c
 *
 * Code generation for function 'Control_data'
 *
 */

/* Include files */
#include "Control_data.h"

/* Variable Definitions */
double oldD;

double integralFactor;

double b_oldD;

boolean_T isInitialized_Control = false;

/* End of code generation (Control_data.c) */
