/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * controlLine.c
 *
 * Code generation for function 'controlLine'
 *
 */

/* Include files */
#include "controlLine.h"
#include "Control_data.h"

/* Function Definitions */
void controlLine_init(void)
{
  b_oldD = 0.0;
}

/* End of code generation (controlLine.c) */
